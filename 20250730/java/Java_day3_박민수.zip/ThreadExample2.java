public class ThreadExample2 {
    public static void main(String[] args) {
        Thread t = new MyThread();
        t.start();
    } 
}
