import java.util.ArrayList;

public class ArrayListPractice {
    public static void main(String[] args) {
        ArrayList<String> ar = new ArrayList<>();
        ar.add("A");
        ar.add("B");
        ar.add("C");
        System.out.println(ar);
    }
}
