public class Multiply{
    public static void main(String[] args) {
        System.out.println(multiply(11, 15));
    }
    public static int multiply(int a, int b){
        return (int)a * b;
    }
}