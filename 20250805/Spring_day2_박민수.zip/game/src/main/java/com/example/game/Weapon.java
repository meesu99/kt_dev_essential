package com.example.game;

public interface Weapon {
    void attack();
    String getName();
}
