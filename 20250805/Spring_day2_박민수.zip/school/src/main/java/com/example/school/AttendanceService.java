// AttendanceService.java
package com.example.school;

public class AttendanceService {
    public void markAttendance(String name) {
        System.out.println("✅ 출석 체크: " + name);
    }
}