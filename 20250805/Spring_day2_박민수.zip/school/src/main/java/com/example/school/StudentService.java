// StudentService.java
package com.example.school;

public class StudentService {
    public void registerStudent(String name) {
        System.out.println("📚 학생 등록: " + name);
    }
}