// GradeService.java
package com.example.school;

public class GradeService {
    public void recordGrade(String subject, int score) {
        System.out.println("📝 성적 기록: " + subject + " - " + score + "점");
    }
}