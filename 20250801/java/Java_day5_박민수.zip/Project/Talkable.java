public interface Talkable {
    void talk();
}
