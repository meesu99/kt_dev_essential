public interface GiftReceivable {
    void receiveGift(String gift);
}
