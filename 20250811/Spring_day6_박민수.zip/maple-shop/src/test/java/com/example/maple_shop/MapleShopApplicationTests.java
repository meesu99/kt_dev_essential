package com.example.maple_shop;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MapleShopApplicationTests {

	@Test
	void contextLoads() {
	}

}
