package com.example.springboot_init;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootInitApplicationTests {

	@Test
	void contextLoads() {
	}

}
